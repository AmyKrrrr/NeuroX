# app/graph/edges.py

NODES_FLOW = [
    "search",
    "scrape",
    "summarize",
    "bias",
    "rewrite",
    "final"
]

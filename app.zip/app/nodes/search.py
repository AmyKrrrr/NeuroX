# app/nodes/search.py

# 🔥 Fallback URLs
FALLBACK_URLS = [
    "https://www.bbc.com/news/world-asia-india-68823827",
    "https://ecfr.eu/special/what_does_india_think/analysis/can_modi_deliver_good_governance",
]

def search_node(state: dict) -> dict:
    query = state.get("query")
    if not query:
        state["urls"] = []
        return state

    print("⚡ Using fallback URLs for query:", query)
    state["urls"] = FALLBACK_URLS
    return state

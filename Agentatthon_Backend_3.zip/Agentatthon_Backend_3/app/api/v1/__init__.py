from fastapi import APIRouter

api_router = APIRouter()

# app/services/llm.py
import time
from google import genai
from google.genai import types

# --- CONFIGURATION ---
# Paste your Working API Key here
API_KEY = "AIzaSyBC6q5c68GYVDRsPK-kGgEHZBV8RZVYiw8" 

# Initialize client once
client = genai.Client(api_key=API_KEY)

def generate_text(prompt: str, model: str = 'gemini-2.0-flash') -> str:
    """
    Global LLM function with automatic Rate Limit handling.
    It waits if it hits a limit, so the app never crashes.
    """
    max_retries = 3
    base_wait = 10 # Start with 10 seconds wait
    
    for attempt in range(max_retries):
        try:
            response = client.models.generate_content(
                model=model, 
                contents=prompt
            )
            return response.text

        except Exception as e:
            error_msg = str(e)
            
            # If we hit the "Speed Limit" (429)
            if "429" in error_msg or "RESOURCE_EXHAUSTED" in error_msg:
                wait_time = base_wait * (attempt + 1) * 2 # Wait 20s, 40s, 60s...
                print(f"⚠️ Rate Limit Hit. Pausing for {wait_time}s to let quota reset...")
                time.sleep(wait_time)
            else:
                # If it's a real error (like Permission Denied), print and return
                print(f"❌ LLM Error: {e}")
                return f"Error: {e}"

    return "I am currently receiving too many requests. Please try again in 2 minutes."
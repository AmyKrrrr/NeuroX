import requests
import trafilatura
import time
import random
from bs4 import BeautifulSoup
from duckduckgo_search import DDGS
from app.agents.base import BaseAgent
from app.agents.result import AgentResult

# Real Browser Headers
HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.5",
    "Referer": "https://www.google.com/"
}

class RetrievalAgent(BaseAgent):
    name = "retrieval_agent"

    async def run(self, query: str) -> AgentResult:
        print(f"🌍 Searching for: {query}")
        urls = []

        # --- STEP 1: ROBUST SEARCH (With Retries) ---
        for attempt in range(3): # Try 3 times
            try:
                with DDGS() as ddgs:
                    # Fetch 10 results
                    results = list(ddgs.text(query, max_results=10))
                    
                    if results:
                        urls = [r['href'] for r in results]
                        print(f"✅ Found {len(urls)} URLs on attempt {attempt+1}")
                        break # Success! Exit loop
                    else:
                        print(f"⚠️ Attempt {attempt+1}: No results found. Retrying...")
                        time.sleep(2) # Wait before retry

            except Exception as e:
                print(f"❌ Search Error (Attempt {attempt+1}): {e}")
                time.sleep(2)

        if not urls:
            return AgentResult(output=[], confidence=0.0, should_continue=False, notes="Search returned 0 URLs after retries")

        # --- STEP 2: SCRAPE WITH FALLBACK ---
        print(f"🕷️ Scraping {len(urls)} URLs...")
        docs = []

        for url in urls:
            if len(docs) >= 3: break # Stop after 3 good docs

            try:
                # Fetch page
                response = requests.get(url, headers=HEADERS, timeout=10)
                if response.status_code != 200: continue

                # Method A: Trafilatura (Best quality)
                text = trafilatura.extract(response.text)

                # Method B: BeautifulSoup (Fallback if Method A fails)
                if not text:
                    soup = BeautifulSoup(response.text, 'html.parser')
                    # Remove junk
                    for tag in soup(["script", "style", "nav", "footer"]):
                        tag.decompose()
                    text = soup.get_text(separator=' ', strip=True)

                # Validate Text
                if text and len(text) > 300:
                    docs.append({"source": url, "content": text})
                    print(f"   ✅ Scraped: {url}")
                
            except Exception:
                continue

        # --- STEP 3: RETURN RESULTS ---
        confidence = 1.0 if len(docs) > 0 else 0.0
        
        return AgentResult(
            output=docs,
            confidence=confidence,
            should_continue=True,
            notes=f"Retrieved {len(docs)} documents"
        )
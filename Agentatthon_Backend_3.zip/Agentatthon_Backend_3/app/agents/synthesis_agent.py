# app/agents/synthesis_agent.py
from app.agents.base import BaseAgent
from app.agents.result import AgentResult
from app.services.llm import generate_text # <--- Import the safe function

class SynthesisAgent(BaseAgent):
    name = "synthesis_agent"

    async def run(self, query: str, docs: list) -> AgentResult:
        if not docs:
            return AgentResult(
                output="I couldn't find any information on that topic.",
                confidence=0.0,
                should_continue=False
            )

        print("🤖 Synthesizing answer with Gemini...")

        # 1. Prepare Data
        context_text = ""
        for d in docs:
            context_text += f"\n--- SOURCE: {d['source']} ---\n{d['content']}\n"
        
        # Limit to ~25k chars
        context_text = context_text[:25000] 

        prompt = f"""
        You are an expert researcher. Answer the user's question based ONLY on the provided sources.
        
        USER QUESTION: {query}
        
        SOURCES:
        {context_text}
        
        INSTRUCTIONS:
        - Write a clear, well-structured report.
        - Use headers (##) and bullet points.
        - If the sources don't contain the answer, say "I couldn't find that info."
        """

        # 2. CALL THE SAFE FUNCTION
        final_answer = generate_text(prompt)

        # Check if it failed
        if final_answer.startswith("Error:") or "too many requests" in final_answer:
             return AgentResult(output=final_answer, confidence=0.0, should_continue=False)

        return AgentResult(
            output=final_answer,
            confidence=1.0,
            should_continue=False,
            notes="Synthesis complete"
        )